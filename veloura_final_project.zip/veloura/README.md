# VELOURA

FastAPI project using APIRouter, with registration, login, and a product catalog.

## Features
- Register and log in with username and password
- Password hashing using `hashlib.pbkdf2_hmac` (PBKDF2-HMAC-SHA256) with a random salt
- Exactly two SQLAlchemy models: `User` and `Product`
- Product fields: name, price, description
- Add and remove products
- `main.html` is the product catalog page after login
- SQLite database

## Structure
```text
veloura/
├── app/
│   ├── main.py
│   ├── database.py
│   ├── models.py
│   ├── schemas.py
│   ├── security.py
│   ├── routers/
│   │   ├── auth.py
│   │   └── products.py
│   └── static/
│       ├── index.html
│       ├── main.html
│       ├── style.css
│       ├── auth.js
│       └── main.js
├── requirements.txt
└── README.md
```

## Run in VS Code (Windows)
```powershell
py -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```
Open http://127.0.0.1:8000 for register/login. After logging in, the app opens `/main`, which serves `main.html`.
API documentation: http://127.0.0.1:8000/docs

## GitHub Desktop
1. Extract this ZIP.
2. Open GitHub Desktop → File → Add Local Repository.
3. Select the extracted `veloura` folder. If it is not a repository yet, choose Create a Repository.
4. Commit to main and choose Publish repository.

## Security note
This is a classroom/demo project. The login UI stores the returned username in sessionStorage for page navigation; it is not a secure server-side authentication session. Before public deployment, add server-side sessions or JWT, HTTPS, CSRF protection, and rate limiting.
