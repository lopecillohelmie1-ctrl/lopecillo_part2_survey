from pathlib import Path
from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from .database import Base, engine
from .routers.auth import router as auth_router
from .routers.products import router as products_router

BASE_DIR = Path(__file__).resolve().parent
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Veloura",
    description="Veloura product catalog with registration and login.",
    version="1.0.0"
)
app.include_router(auth_router)
app.include_router(products_router)
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")

@app.get("/", include_in_schema=False)
def login_page():
    return FileResponse(BASE_DIR / "static" / "index.html")

@app.get("/main", include_in_schema=False)
def main_page():
    return FileResponse(BASE_DIR / "static" / "main.html")
